import React from 'react';
import OurShopSec1 from './OurShopSections/OurShopSec1';
import OusShopSec2 from './OurShopSections/OurShopSec2';


const OurShop = () => {
  return (
    <>
    <OurShopSec1/>
    <OusShopSec2/>
    </>
  )
}

export default OurShop;