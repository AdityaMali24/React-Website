import React from 'react'
import ContactSec1 from './ContactUs/ContactSec1'
import ContactSec2 from './ContactUs/ContactSec2'

const ContactUs = () => {
  return (
    <>
    <ContactSec1/>
    <ContactSec2/>
    </>
  )
}

export default ContactUs